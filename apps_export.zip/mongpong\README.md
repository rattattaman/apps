mongPong — Notas rápidas

- Controles teclado: P1 W/S · P2 ↑/↓ · P Pausa · R Reinicio · A Alterna IA P2 · M Silenciar/activar sonido.
- Controles táctiles: arrastra en la mitad izquierda para mover P1; si la IA está desactivada, arrastra en la mitad derecha para mover P2.
- Mods (botón «Mods»): velocidad por bote, tamaño aleatorio, dos pelotas, pared (IA), espejo, spin, gravedad, estela y teletransporte al rebotar en pared.
- Nuevo: Dificultad IA (slider) — ajusta la reacción/velocidad de la IA.
- Nuevo: Botón Pantalla completa.
- Nuevo: Guardado automático de ajustes (mods/IA/sonido) en localStorage.

Cómo ejecutar

- Abre directamente `index.html` en tu navegador (no requiere servidor).
- Si el sonido no se oye, toca la pantalla o pulsa una tecla primero (política de autoplay), o usa el botón «Sonido/Mute» en Mods.

